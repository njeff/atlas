/*
PORTC:
	0 LCD
	1 LCD
	2 LCD
	3 LCD
	4 Camera Focus
	5 Camera Shutter
	6 
	7 
PORTD:
	0 ENC A
	1 ENC B
	2 ENC BUTTON
	3 MENU BUTTON
	4 START BUTTON
	5 
	6 
	7 
PORTB:
	0 LCD E
	1
	2
	3
	4 Stepper Step
	5 Stepper DIR
	6 LCD RS
	7 LCD RW
*/

#ifndef ENCODER_H_
#define ENCODER_H_

#define INP_CTL DDRD
#define INP_WR PORTD
#define INP_RD PIND
#define ENC_A 0
#define ENC_B 1
#define ENC_BUTTON 2
#define B_MENU 3
#define B_START 4

#define INP_RC PINC
#define SHUTTER 5
#define FOCUS 4

#define SSTEP 5
#define SDIR 4

void initInputs(void);

int8_t getEncoder(void);
uint8_t getButtons(void);

#endif
