#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include "millis.h"
#include "lcd.h"
#include "inputs.h"

//steps stepper motor
void stepMotor(int dir, int delay){
	if(dir == 0){
		return;
	}
	else if(dir == -1){
		PORTB |= 1<<SDIR;
	}
	else if(dir == 1){
		PORTB &= ~(1<<SDIR);
	}
	PORTB ^= (1<<SSTEP);
	_delay_us(delay);
	PORTB ^= (1<<SSTEP);
	_delay_us(delay);
}

int main(void){
	initInputs();
	lcd_init(LCD_DISP_ON);
	lcd_clrscr();
	millis_init();
		
	PORTC = 0x00;
	while(1){
		//setup menu layout
		lcd_gotoxy(1,0);
		lcd_puts("End Start Positions");
		lcd_gotoxy(1,1);
		lcd_puts("# of Frames       0");
		lcd_gotoxy(1,2);
		lcd_puts("Duration (min)    0");
		lcd_gotoxy(1,3);
		lcd_puts("sec/frame         0");
		
		//////////get end position
		int motorSpeed = 0;
		
		lcd_gotoxy(0,0);
		lcd_puts(">");
		while(1){
			int8_t encval = getEncoder();
			uint8_t buttonval = getButtons();
			if(encval>=1){ //encoder turned clockwise
				if(motorSpeed < 2){
					motorSpeed++;
				}
			} else if (encval<=-1){ //encoder turned counter-clockwise
				if(motorSpeed > -2){
					motorSpeed--;
				}
			}
		
			if((buttonval & 0x02)){ //enter/exit menu
				break;
			}
			if((buttonval & 0x01)){ //encoder button
				motorSpeed = 0;
			}
			
			//move motor
			if(motorSpeed > 0){
				stepMotor(1,4/motorSpeed);
			} else if(motorSpeed < 0){
				stepMotor(-1,4/(motorSpeed*-1)); //multiply by -1 will cause this direction to run slower
			}
		}
		
		//////////get start position
		int32_t steps = 0;
		motorSpeed = 0;
		
		lcd_gotoxy(0,0);
		lcd_puts(" ");
		lcd_gotoxy(4,0);
		lcd_puts(">");
		while(1){
			int8_t encval = getEncoder();
			uint8_t buttonval = getButtons();
			if(encval>=1){ //encoder turned clockwise
				if(motorSpeed < 2){
					motorSpeed++;
				}
			} else if (encval<=-1){ //encoder turned counter-clockwise
				if(motorSpeed > -2){
					motorSpeed--;
				}
			}
			
			if((buttonval & 0x02)){ //enter/exit menu
				break;
			}
			if((buttonval & 0x01)){ //encoder button
				motorSpeed = 0;
			}
			
			//move motor
			if(motorSpeed > 0){
				stepMotor(1,4/motorSpeed);
			} else if(motorSpeed < 0){
				stepMotor(-1,4/(motorSpeed*-1));
			}
			
			//count steps
			if(motorSpeed > 0){
				steps++;
			}
			if(motorSpeed < 0){
				steps--;
			}
		}
		
		//////////get number of frames
		int32_t frames = 0;
		char buffer[5];
		
		lcd_gotoxy(4,0);
		lcd_puts(" ");
		lcd_gotoxy(0,1);
		lcd_puts(">");
		while(1){
			int8_t encval = getEncoder();
			uint8_t buttonval = getButtons();
			if(encval>=1){ //encoder turned clockwise
				frames += 10;

			} else if (encval<=-1){ //encoder turned counter-clockwise
				if(frames!=0){
					frames -=10;
				}
			}
			
			if(encval != 0){
				sprintf(buffer,"%5lu",frames);
				lcd_gotoxy(15,1);
				lcd_puts(buffer);
			}
			
			if((buttonval & 0x02)){ //enter/exit menu
				break;
			}
			if((buttonval & 0x01)){ //encoder button
				
			}
		}
		
		//////////get duration
		uint32_t minutes = 0;
		millis_t totalTime = 0;
		uint32_t timeBetweenFrames = 0;
		
		lcd_gotoxy(0,1);
		lcd_puts(" ");
		lcd_gotoxy(0,2);
		lcd_puts(">");
		while(1){
			int8_t encval = getEncoder();
			uint8_t buttonval = getButtons();
			if(encval>=1){ //encoder turned clockwise
				minutes += 10;
				
			} else if (encval<=-1){ //encoder turned counter-clockwise
				if(minutes!=0){
					minutes -=10;
				}
			}
			
			if(encval != 0){
				sprintf(buffer,"%5lu",minutes);
				lcd_gotoxy(15,2);
				lcd_puts(buffer);
				totalTime = minutes*60*1000; //convert to millis
				timeBetweenFrames = totalTime/(frames-1);
				sprintf(buffer,"%5lu",timeBetweenFrames/1000);
				lcd_gotoxy(15,3);
				lcd_puts(buffer);
			}
			
			if((buttonval & 0x02)){ //enter/exit menu
				break;
			}
			if((buttonval & 0x01)){ //encoder button
				
			}
		}	
		
		//////////check exposure length (so we know when to move camera)
		uint16_t exposure = 0;
		
		lcd_gotoxy(0,2);
		lcd_puts(" ");
		lcd_gotoxy(0,3);
		lcd_puts(">Exposure (sec)    0");
		while(1){
			int8_t encval = getEncoder();
			uint8_t buttonval = getButtons();
			if(encval>=1){ //encoder turned clockwise
				if(exposure < ((timeBetweenFrames/1000)-2)){
					exposure++;
				}
				
			} else if (encval<=-1){ //encoder turned counter-clockwise
				if(exposure>0){
					exposure--;
				}
			}
			
			if(encval != 0){
				sprintf(buffer,"%5d",exposure);
				lcd_gotoxy(15,3);
				lcd_puts(buffer);
			}
			
			if((buttonval & 0x02)){ //enter/exit menu
				break;
			}
			if((buttonval & 0x01)){ //enter/exit edit mode
				
			}
		}		
		
		int32_t stepsBetweenFrames = steps/(frames-1);
		
		//directions are inverted because end position was set first
		int8_t dir = -1;
		if(stepsBetweenFrames != 0){ //make sure if there is no move add no compensation
			if(stepsBetweenFrames<0){ //determine direction
				dir = 1;
				stepsBetweenFrames = -1*stepsBetweenFrames;
			}
		}
		
		exposure *= 1000; //convert to milliseconds
		//setup display
		lcd_clrscr();
		lcd_puts("Frames left:");
		lcd_gotoxy(0,1);
		lcd_puts("Time Left:");
		lcd_gotoxy(0,2);
		lcd_puts("Next Frame in:");
		lcd_gotoxy(0,3);
		lcd_puts("Motor Stopped");
		sprintf(buffer,"%5lu",frames); //show frame count
		lcd_gotoxy(15,0);
		lcd_puts(buffer);
		//setup all time variables
		millis_t currentTime = millis_get();
		millis_add((millis_t)timeBetweenFrames); //take first photo immediately
		millis_t lastTime = currentTime; //time when last frame was taken
		millis_t endTime = millis_get() + totalTime; //time when the timelapse will end
		millis_t lastUpdate = currentTime; //time when the times were last updated
		uint32_t timeLeft = (endTime-millis_get())/1000; //time left in the timelapse
		uint32_t hours = timeLeft/3600; //hours left
		
		char timeBuffer[8];
		sprintf(timeBuffer,"%02lu:%02lu:%02lu",hours,(timeLeft-(hours*3600))/60,timeLeft%60);
		lcd_gotoxy(12,1);
		lcd_puts(timeBuffer);
		PORTC |= (1<<FOCUS); //focus for first shot
		_delay_ms(1000);
		
		int32_t ramp = stepsBetweenFrames/20;
		int32_t unramp = stepsBetweenFrames-ramp;
		
		//flags
		uint8_t moved = 1;
		uint8_t focused = 1;
		
		while(frames>0){
			currentTime = millis_get();
			//take photo
			if((currentTime-lastTime) > timeBetweenFrames){
				PORTC |= (1<<SHUTTER); //trigger
				_delay_ms(5);
				PORTC &= ~((1<<SHUTTER)|(1<<FOCUS)); //release
				lastTime = currentTime;
				moved = 0;
				focused = 0;
				frames--;
				sprintf(buffer,"%5lu",frames); //show frame count
				lcd_gotoxy(15,0);
				lcd_puts(buffer);
			}
			//focus a second before capture
			if(((currentTime-lastTime) > (timeBetweenFrames-1000)) && (focused==0)){
				PORTC |= (1<<FOCUS);
				focused = 1;
			}
			//move motor 0.5 seconds after taking photo
			if((currentTime > (lastTime+exposure+500))&&(moved==0)){
				moved = 1;
				lcd_gotoxy(6,3);
				lcd_puts("Moving ");
				//trapezoidal velocity profile
				//time will not update when moving (small bug, but most of the time moves are very short)
				for(uint32_t stepF = 0; stepF<stepsBetweenFrames; stepF++){
					if(stepF<ramp){ //ramp up
						stepMotor(dir,1000-(950*stepF/ramp));
					} else if(stepF>unramp){ //ramp down
						stepMotor(dir,50+(950*(stepF-unramp)/ramp));
					} else { //constant rate
						stepMotor(dir,50);
					}
				}
				lcd_gotoxy(6,3);
				lcd_puts("Stopped");
			}
			//update time left and time to next frame
			if(currentTime-lastUpdate > 100){ //refresh rate of 10 Hz
				timeLeft = (endTime-currentTime)/1000;
				hours = timeLeft/3600;
				sprintf(timeBuffer,"%02lu:%02lu:%02lu",hours,(timeLeft-(hours*3600))/60,timeLeft%60); //time left
				lcd_gotoxy(12,1);
				lcd_puts(timeBuffer);
				
				sprintf(buffer,"%5lu",(timeBetweenFrames-(currentTime-lastTime))/1000); //seconds to next frame
				lcd_gotoxy(15,2);
				lcd_puts(buffer);
				lastUpdate = currentTime;
			}
		}
		lcd_gotoxy(15,3);
		lcd_puts("Done!");
		_delay_ms(1000);
		lcd_clrscr();
	}
}
