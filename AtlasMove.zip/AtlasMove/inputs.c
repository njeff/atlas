#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include "millis.h"
#include "inputs.h"
#include "lcd.h"

static int8_t encAmt = 0; //encoder value
static uint8_t button = 0;
static uint8_t buttonInt = 0;
static millis_t lastChangeEnc = 0;
static millis_t lastChangeMenu = 0;

void initInputs(void){
	cli();
	PCICR |= (1<<PCIE2); //enable PORTD pin change interrupt
	
	//set up encoder and buttons
	INP_WR |= ((1<<ENC_A)|(1<<ENC_B)|(1<<ENC_BUTTON)|(1<<B_MENU)); //turn on pull up resistors
	PCMSK2 |= ((1<<PCINT16)|(1<<PCINT17)|(1<<PCINT18)|(1<<PCINT19)); //setup interrupt mask
	
	DDRC |= ((1<<SHUTTER)|(1<<FOCUS));
	DDRB |= ((1<<SSTEP)|(1<<SDIR));
	
	PORTB &= ~((1<<SSTEP)|(1<<SDIR));
	
	//set up buttons
	sei();
}

int8_t getEncoder(void){
	int8_t temp = encAmt;
	encAmt = 0;
	return temp;
}

uint8_t getButtons(void){
	uint8_t temp = buttonInt;
	buttonInt = 0;
	return temp;
}

/* Encoder code adapted from: http://www.circuitsathome.com/mcu/rotary-encoder-interrupt-service-routine-for-avr-micros
		 Lookup Table
------------------------------
		 Current Value
		 00 01 10 11
	  00|0 |-1|1 |0 |
Old	  01|1 |0 |0 |-1|
Value 10|-1|0 |0 |1 |
	  11|0 |1 |-1|0 |
	  
This could also be implemented by XNORing the encoder bits when one pin transitions
	This has half the amount of resolution but is fine for this encoder because it transitions twice with every revolution
*/

ISR(PCINT2_vect){	
	static uint8_t buttonOld = 0x03;
	static uint8_t encOld = 0;
	static int8_t encVal = 0;
	static const int8_t lookup[] PROGMEM = {0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};

	if((encOld & 0x03) != (INP_RD & 0x03)){ //is it an encoder change?
		encOld <<= 2; //shift old state over two (the previous "new state")
		encOld |= (INP_RD & 0x03); //OR in the new state (other pins masked out)
		encVal += pgm_read_byte(&(lookup[(encOld & 0x0F)])); //get the appropriate increment/decrement amount
		if(encVal > 1){
			encAmt++;
			encVal = 0;
		}
		if(encVal < -1){
			encAmt--;
			encVal = 0;
		}
	} else { //it is a button change
		button = (INP_RD & 0x0C)>>2;
		uint8_t encOld = buttonOld & 0x01;
		uint8_t menuOld = buttonOld & 0x02;
		uint8_t encCur = button & 0x01;
		uint8_t menuCur = button & 0x02;
		
		millis_t now = millis();
		//check encoder
		if(encOld != encCur){ //if there was a change
			if(now-lastChangeEnc >= 50){ //debounce
				if(encCur == 0){ //if the button was pressed
					buttonInt |= (1<<0);
				}
				else{ //if released
					//buttonInt &= ~(1<<0);
				}
				lastChangeEnc = now;
			}
		}
		//check menu
		if(menuOld != menuCur){ //if there was a change
			if(now-lastChangeMenu >= 50){ //debounce
				if(menuCur == 0){ //if the button was pressed
					buttonInt |= (1<<1);
				}
				else{ //if released
					//buttonInt &= ~(1<<1);
				}
				lastChangeMenu = now;
			}
		}
		buttonOld = button;
	}
}
